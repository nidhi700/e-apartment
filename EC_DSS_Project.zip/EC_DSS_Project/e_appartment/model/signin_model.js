var db=require('../dbconnection');

var item = {
    isauth1:function(item, callback) {
        console.log("inside model");
        return db.query('select * from user where username = ? and  password = ? ', [item.username, item.password], callback);
    },
   
};

module.exports = item;